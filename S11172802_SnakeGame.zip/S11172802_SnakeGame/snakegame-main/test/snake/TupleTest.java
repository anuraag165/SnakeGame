package snake;

import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;

public class TupleTest
{
    
    public TupleTest() 
    {
    	// tuple test
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    //Test of getX method of the class Tuple.
    @Test
    public void testGetX() 
    {
        System.out.println("getX");
        Tuple instance = null;
        int ExpectedResult = 0;
    }

    //Test of getY method of the class Tuple.
    @Test
    public void testGetY() 
    {
        System.out.println("getY");
        Tuple instance = null;
        int ExpectedResult = 0;
     }

    //Test of getXf method of the class Tuple.
    @Test
    public void testGetXf() 
    {
        System.out.println("getXf");
        Tuple instance = null;
        int ExpectedResult = 0;
    }

    
     //Test of getYf method of the class Tuple.
     
    @Test
    public void testGetYf()
    {
        System.out.println("getYf");
        Tuple instance = null;
        int ExpectedResult = 0;
     }
    
}
