package snake;

import java.awt.Color;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

public class SquarePanelTest 
 
{    // test for the SquarePanelTest
    
    public SquarePanelTest() 
    {
    	// SquarePanelTest
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    

   // The test for the ChangeColor of the SquarePanel
    @Test
    public void testChangeColor() 
    {
        System.out.println("ChangeColor"); // prints the change color
        Color d = null; // set to null
        SquarePanel instance = null; // instance set to null
        
    }
    
}
