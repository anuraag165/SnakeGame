package snake;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.AfterClass;
import static org.junit.Assert.*;

public class MainTest // test class for the main
{
    
    public MainTest() 
    {
    	// public main test
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    // The test for the main of the Main file
    @Test
    public void testMain()
    {
        System.out.println("main");
        String[] args = null;
        Main.main(args);
 
    }
    
}
