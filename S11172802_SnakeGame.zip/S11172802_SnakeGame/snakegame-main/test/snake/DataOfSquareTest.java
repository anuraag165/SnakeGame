package snake;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.After;

public class DataOfSquareTest { 
    
    public DataOfSquareTest() 
    {
    	// data of Square test
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

 // The test for the lightMeUp of the DataOfSquare
    @Test
    public void testLightMeUp()
    {
        System.out.println("lightMeUp");
        int c = 0;
        DataOfSquare instance = null;
    }
    
}
